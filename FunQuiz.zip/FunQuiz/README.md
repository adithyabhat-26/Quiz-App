# FunQuizApp
A Quiz With Sqlite
 Hello ! Everybody
 So this app is built by using a Sqlite in Android Studio 
 
done by
Prajwal Bhat
Adithya Bhat
M Akshatha Prabhu

of NMAM Institute of Technology



