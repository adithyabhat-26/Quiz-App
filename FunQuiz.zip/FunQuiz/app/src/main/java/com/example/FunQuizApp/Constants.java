package com.example.FunQuizApp;

public class Constants {
    public static final String COMPUTERS = "Computers";
    public static final String HISTORY = "History";
    public static final String ENGLISH = "English";
    public static final String MATHS = "Maths";
    public static final String GRAPHICS = "Graphics";
}
